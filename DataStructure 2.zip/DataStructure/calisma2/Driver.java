public class Driver {

public static void main(String[] args) {
    HeapPriorityQueue new2=new HeapPriorityQueue();
    new2.insert(2,"A");
    new2.insert(3,"B");
    new2.insert(4,"C");
    new2.insert(10,"K");
    System.out.println(new2.hasLeft(0));
    System.out.println(new2.max());
    //new2.findNode(0, 4);
}
}