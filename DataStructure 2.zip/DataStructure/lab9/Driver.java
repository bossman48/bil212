public class Driver {
	public static void main(String[] args){
		TreeMap<Integer,Integer> t=new TreeMap<>();
		t.put(20, 200);
		t.put(10, 100);
		t.put(30, 300);
		t.put(5, 50);
		t.put(15, 150);
		t.display();
		t.put(7, 70);
		t.display();
		t.rotateR(t.root());
		t.display();
		
		AVLTreeMap<Integer,Integer> avl=new AVLTreeMap<>();
	}
}