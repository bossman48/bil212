import java.util.Stack;

public class stackQueue {
	public static void main(String[] args) {
            Stack<Integer> asd=new Stack<>();
            asd.push(12);
            asd.push(14);
            System.out.println(asd.pop());
    }  

}