import java.io.*; 
import java.util.*; 
  
class iteratorCalisma { 
    public static void main(String[] args) 
    { 
        ArrayList<String> list = new ArrayList<String>(); 
  
        list.add("A"); 
        list.add("B"); 
        list.add("C"); 
        list.add("D"); 
        list.add("E"); 
  
        // Iterator to traverse the list 
        Iterator iterator = list.iterator(); 
        ListIterator iterator2 = list.listIterator(); 
  
        System.out.println("List elements : "); 
        int k=0;
        while (iterator.hasNext()) 
            System.out.print(iterator.next() + " "); 
            System.out.println();
        while (iterator2.hasNext()){ 
            System.out.print(iterator2.next() + " "); 
            k++;
        }
        System.out.println();
            while(k>0){
            System.out.print(iterator2.previous() + " "); 
            k--;
            }
  
        System.out.println(); 
    } 
} 