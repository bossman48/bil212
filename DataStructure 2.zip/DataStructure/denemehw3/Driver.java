public class Driver {

public static void main(String[] args) {
/*    HeapPriorityQueue new2=new HeapPriorityQueue();
    new2.insert(2,"A");
    new2.insert(3,"B");
    new2.insert(4,"C");
    new2.insert(10,"K");*/
    LinkedBinaryTree<String> tree=new LinkedBinaryTree<>();
    Position<String> asd=tree.addRoot("C");
    tree.addRight(asd,"K");
}
}