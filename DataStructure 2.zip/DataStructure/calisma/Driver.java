import java.util.LinkedList;
import java.util.ListIterator;


public class Driver {
        final static int NUM=200000;

	public static void main(String[] args) {
	      LinkedList<Integer> list = new LinkedList<>();
	      for (int i=0; i<NUM; i++)
                    list.add(i);

		long start = System.currentTimeMillis();
	      for (int i=0; i< NUM; i++) {
			list.set(i, 100);

		}
		long end = System.currentTimeMillis();
       
		System.out.println(end-start);



		start = System.currentTimeMillis();

              ListIterator<Integer> it = list.listIterator();
              while (it.hasNext()) {
			it.next();
			it.set(100);
		}
		end = System.currentTimeMillis();
       
		System.out.println(end-start);
	

        }

}
