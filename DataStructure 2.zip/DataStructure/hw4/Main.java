
public class Main {
	 public static void main(String[] args) {
		 
	        KDTree2D tree = new KDTree2D();
	        
	        Point2D p1 = new Point2D();
	        p1.setLocation(30, 40);
	        Point2D p2 = new Point2D();
	        p2.setLocation(5, 25);
	        Point2D p3 = new Point2D();
	        p3.setLocation(10, 12);
	        Point2D p4 = new Point2D();
	        p4.setLocation(70, 70);
	        Point2D p5 = new Point2D();
	        p5.setLocation(50, 30);
	        Point2D p6 = new Point2D();
	        p6.setLocation(35, 45);
	        
	        tree.insert(p1);
	        tree.insert(p2);
	        tree.insert(p3);
	        tree.insert(p4);
	        tree.insert(p5);
	        tree.insert(p6);
	        
	        System.out.println("Search for values");
	        System.out.println(tree.search(p1));
	        System.out.println(tree.search(p4));
	        System.out.println(tree.search(p5));
	        System.out.println();
	        
	        
	        System.out.println("Traverse tree");
	        tree.toString();
	        System.out.println();
	        System.out.println("FindMin in dimension x");
	        System.out.println(tree.findMin(0));
	        System.out.println("FindMin in dimension y");
	        System.out.println(tree.findMin(1));
	        System.out.println("FindMax in dimension x");
	        System.out.println(tree.findMax(0));
	        System.out.println("FindMax in dimension y");
	        System.out.println(tree.findMax(1));
	    }
}
