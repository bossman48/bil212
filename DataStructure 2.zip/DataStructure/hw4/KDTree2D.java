import java.util.ArrayList;
 
public class KDTree2D {
    private Point2D point;
    private KDTree2D left, right;
    private boolean toComp;
    public int size;
 
    public KDTree2D() {
    	size = 0;
    }
 
	public KDTree2D(ArrayList<Point2D> points) {
		size = points.size();
	}

	public boolean isEmpty() {
        return size == 0;
    }
 
    public void insert(Point2D p) {
        insert2(p);
    }
 
    private boolean insert2(Point2D p) {
        if (p == null) {
            throw new NullPointerException();
        }
        if (point == null) {
            point = p;
            toComp = true;
            size = 1;
            return true;
        } 
        if (point.equals(p)) 
            return false;
        
        size++;
        
        boolean isDone = true;
        if ((toComp && p.getX() <= point.getX()) || (!toComp && p.getY() <= point.getY())) {
            if (left == null) {
                left = new KDTree2D();
                left.point = p;
                left.toComp = !toComp;
                left.size = 1;
            } else {
                isDone = left.insert2(p);
                if (!isDone) 
                	size--;
            }
        } else {
            if (right == null) {
                right = new KDTree2D();
                right.point = p;
                right.toComp = !toComp;
                right.size = 1;
            } else {
                isDone = right.insert2(p);
                if (!isDone) 
                	size--;
            }
        }
        return isDone;
    }
 
    private Point2D search2(KDTree2D root, Point2D p) {	
        if (root != null) {
            if(root.point.equals(p))
            	return p;
            search2(root.left, p);
            search2(root.right, p);
        }
        return null;
    }
 
    public Point2D search(Point2D p) {
        if (point != null)
        {
            search2(left, p);
            search2(right, p);
        }
        return p;
    }
    private void preorder2(KDTree2D root, int level) {	
        if (root != null) {
        	for(int i = 0; i< level; i++)
        		System.out.print(" ");
            System.out.println(root.point.toString());
            preorder2(root.left, ++level);
            preorder2(root.right, ++level);
        }
    }
 
    private void preorder() {
        if (point != null)
        {
            System.out.println("" + point.toString());
            preorder2(left, 1);
            preorder2(right, 1);
        }
    }
    public String toString() {
    	preorder();
    	return "";
    }
    
    private static Point2D min(Point2D a, Point2D b, int d) {
    	if(d == 0) {
    		double valOfA, valOfB;
        	if(a == null)
        		valOfA = Double.MAX_VALUE;
        	else
        		valOfA = a.getX();
        	if(b == null) 
        		valOfB = Double.MAX_VALUE;
        	else
        		valOfB = b.getX();
    		if(valOfA <= valOfB)
    			return a;
    		else
    			return b;
    	}	
    	else{
    		double valOfA, valOfB;
        	if(a == null)
        		valOfA = Double.MAX_VALUE;
        	else
        		valOfA = a.getY();
        	if(b == null) 
        		valOfB = Double.MAX_VALUE;
        	else
        		valOfB = b.getY();
    		if(valOfA <= valOfB)
    			return a;
    		else
    			return b;
    	}
    }
    private static Point2D min2(Point2D a, Point2D b, Point2D c, int d) {
    	if(d == 0) {
    		double valOfA, valOfB, valOfC;
        	if(a == null)
        		valOfA = Double.MAX_VALUE;
        	else
        		valOfA = a.getX();
        	if(b == null) 
        		valOfB = Double.MAX_VALUE;
        	else
        		valOfB = b.getX();
        	if(c == null) 
        		valOfC = Double.MAX_VALUE;
        	else
        		valOfC = c.getX();
    		if(valOfA <= valOfB && valOfA <= valOfC)
    			return a;
    		else if(valOfB <= valOfA && valOfB <= valOfC)
    			return b;
    		else
    			return c;
    	}	
    	else{
    		double valOfA, valOfB, valOfC;
        	if(a == null)
        		valOfA = Double.MAX_VALUE;
        	else
        		valOfA = a.getY();
        	if(b == null) 
        		valOfB = Double.MAX_VALUE;
        	else
        		valOfB = b.getY();
        	if(c == null) 
        		valOfC = Double.MAX_VALUE;
        	else
        		valOfC = c.getY();
    		if(valOfA <= valOfB && valOfA <= valOfC)
    			return a;
    		else if(valOfB <= valOfA && valOfB <= valOfC)
    			return b;
    		else
    			return c;
    	}
    }
    
    private static Point2D max(Point2D a, Point2D b, int d) {
    	if(d == 0) {
    		double valOfA, valOfB;
        	if(a == null)
        		valOfA = Double.MIN_VALUE;
        	else
        		valOfA = a.getX();
        	if(b == null) 
        		valOfB = Double.MIN_VALUE;
        	else
        		valOfB = b.getX();
    		if(valOfA >= valOfB)
    			return a;
    		else
    			return b;
    	}	
    	else{
    		double valOfA, valOfB;
        	if(a == null)
        		valOfA = Double.MIN_VALUE;
        	else
        		valOfA = a.getY();
        	if(b == null) 
        		valOfB = Double.MIN_VALUE;
        	else
        		valOfB = b.getY();
    		if(valOfA >= valOfB)
    			return a;
    		else
    			return b;
    	}
    }
    private static Point2D max2(Point2D a, Point2D b, Point2D c, int d) {
    	if(d == 0) {
    		double valOfA, valOfB, valOfC;
        	if(a == null)
        		valOfA = Double.MIN_VALUE;
        	else
        		valOfA = a.getX();
        	if(b == null) 
        		valOfB = Double.MIN_VALUE;
        	else
        		valOfB = b.getX();
        	if(c == null) 
        		valOfC = Double.MIN_VALUE;
        	else
        		valOfC = c.getX();
    		if(valOfA >= valOfB && valOfA >= valOfC)
    			return a;
    		else if(valOfB >= valOfA && valOfB >= valOfC)
    			return b;
    		else
    			return c;
    	}	
    	else{
    		double valOfA, valOfB, valOfC ;
        	if(a == null)
        		valOfA = Double.MIN_VALUE;
        	else
        		valOfA = a.getY();
        	if(b == null) 
        		valOfB = Double.MIN_VALUE;
        	else
        		valOfB = b.getY();
        	if(c == null) 
        		valOfC = Double.MIN_VALUE;
        	else
        		valOfC = c.getY();
    		if(valOfA >= valOfB && valOfA >= valOfC)
    			return a;
    		else if(valOfB >= valOfA && valOfB >= valOfC)
    			return b;
    		else
    			return c;
    	}
    }    
    private Point2D findMinRec(KDTree2D root, int d, int depth) { 
        if (root == null) 
            return null; 
      
        return min2(root.point, findMinRec(root.left, d, depth + 1), findMinRec(root.right, d, depth + 1), d); 
    } 
    public Point2D findMin(int d) { 
        if(size == 1)
        	return point;
        return min2(point, findMinRec(left, d, 0), findMinRec(right, d, 0), d); 
    } 
    private Point2D findMaxRec(KDTree2D root, int d, int depth) { 
        if (root == null) 
            return null; 
      
        return max2(root.point, findMaxRec(root.left, d, depth + 1), findMaxRec(root.right, d, depth + 1), d); 
    } 
    public Point2D findMax(int d) { 
        if(size == 1)
        	return point;
        return max2(point, findMaxRec(left, d, 0), findMaxRec(right, d, 0), d); 
    }       
}
