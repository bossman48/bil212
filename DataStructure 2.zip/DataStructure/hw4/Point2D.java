
public class Point2D {
	public double x;
	
    public double y;
    
    public Point2D() {
    	x = 0;
    	y = 0;
    }
    public Point2D(double x, double y) {
    	this.x = x;
    	this.y = y;
    }
    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
    
    public void setLocation(double x, double y) {
        this.x = x;
        this.y = y;
    }
    
    public String toString() {
    	if((x-(int)x) > 0 && (x-(int)x) <1)
    		return (double)Math.round(x * 100d) / 100d + " " + (double)Math.round(y * 100d) / 100d;
    	else
    		return (int)x + " " + (int)y;
    }
}
