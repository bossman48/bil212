public interface PubliclyCloneable
{
    
}